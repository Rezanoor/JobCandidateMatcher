// This file can be replaced during build by using the `fileReplacements` array.
// `ng build ---prod` replaces `environment.ts` with `environment.prod.ts`. ng build --prod --configuration=prod
// The list of file replacements can be found in `angular.json`.

export const environment = {
    production: true,
    JobCandidateBaseUrl: "/CommitteeAPI/api/committee/",
};

