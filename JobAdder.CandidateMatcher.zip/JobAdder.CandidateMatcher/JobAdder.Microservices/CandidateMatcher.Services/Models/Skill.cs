﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandidateMatcher.Services.Models
{
    public class Skill
    {
        public string name { get; set; }
        public int weight { get; set; }
    }
}
