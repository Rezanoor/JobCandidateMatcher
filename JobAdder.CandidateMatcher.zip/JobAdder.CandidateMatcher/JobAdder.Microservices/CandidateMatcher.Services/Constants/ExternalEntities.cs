﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandidateMatcher.Services.Constants
{
    public class ExternalEntities
    {
        public const string CANDIDATES = "candidates";
        public const string JOBS = "jobs";
    }
}
