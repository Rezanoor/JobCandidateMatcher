﻿

namespace CandidateMatcher.Common.Models.Configurations
{
    public class JobAdderApiConfiguration
    {
        public const string JobAdderApi = "JobAdderApi";
        public string BaseUrl { get; set; }
    }
}
