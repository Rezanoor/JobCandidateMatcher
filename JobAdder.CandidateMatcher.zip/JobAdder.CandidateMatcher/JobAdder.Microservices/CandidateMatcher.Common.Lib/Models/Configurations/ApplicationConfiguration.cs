﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandidateMatcher.Common.Models.Configurations
{
    public class ApplicationConfiguration
    {
        public const string Application = "Application";
        public string AllowCorsURL { get; set; }
    }
}
