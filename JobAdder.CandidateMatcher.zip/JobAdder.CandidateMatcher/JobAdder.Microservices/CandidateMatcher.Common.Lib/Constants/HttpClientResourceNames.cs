﻿using System;
using System.Collections.Generic;
using System.Text;

namespace CandidateMatcher.Common.Constants
{
    public class HttpClientResourceNames
    {
        public const string JOB_ADDER_API = "JOB_ADDER_API";
    }
}
